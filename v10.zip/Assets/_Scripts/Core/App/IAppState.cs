public interface IAppState
{
    void Enter();   // L�gica al entrar al estado
    void Exit();    // L�gica al salir del estado
}