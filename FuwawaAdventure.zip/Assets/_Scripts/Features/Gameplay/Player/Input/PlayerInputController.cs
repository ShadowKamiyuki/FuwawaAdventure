using UnityEngine;

public class PlayerInputController : MonoBehaviour
{
    private IInputService _input;
    private PlayerActions _actions;

    private void Awake()
    {
        _input = ServiceLocator.Get<IInputService>();
        _actions = GetComponent<PlayerActions>();
    }

    private void OnEnable()
    {
        _input.AttackStarted += OnAttackStarted;
        _input.AttackCanceled += OnAttackCanceled;
        _input.JumpPressed += OnJump;
        _input.InteractPressed += OnInteract;
    }

    private void OnDisable()
    {
        _input.AttackStarted += OnAttackStarted;
        _input.AttackCanceled += OnAttackCanceled;
        _input.JumpPressed += OnJump;
        _input.InteractPressed += OnInteract;
    }

    private void Update()
    {
        _actions.SetMoveDirection(_input.Movement);
    }

    private void OnAttackStarted() => _actions.Attack();
    private void OnAttackCanceled() { }
    private void OnJump() => _actions.Jump();
    private void OnInteract() => _actions.Interact();
}
