using UnityEngine;

public class PlayerActions : MonoBehaviour
{
    private Rigidbody rb;

    private Vector3 _moveDirection;

    [SerializeField] private float speed;
    [SerializeField] private float jumpForce;

    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
    }

    private void FixedUpdate()
    {
        Move();
    }

    public void SetMoveDirection(Vector2 direction)
    {
        _moveDirection = new Vector3(direction.x, 0, direction.y).normalized;
    }

    private void Move()
    {
        rb.velocity = _moveDirection * speed;
    }

    public void Jump()
    {
        rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
    }

    public void Interact()
    {
        //_currentInteractable?.Interact(this);
    }

    public void Attack()
    {
        // agregar el ataque
        Debug.Log("Attack");
    }

    private void OnTriggerEnter(Collider other)
    {
        //_currentInteractable = other.GetComponent<IInteractable>();
    }

    private void OnTriggerExit(Collider other)
    {
        //if (other.GetComponent<IInteractable>() == _currentInteractable)
        //    _currentInteractable = null;
    }
}
