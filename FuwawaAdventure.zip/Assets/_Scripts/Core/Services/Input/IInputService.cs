using System;
using UnityEngine;

public interface IInputService
{
    Vector2 Movement { get; }

    event Action AttackStarted;
    event Action AttackCanceled;
    event Action JumpPressed;
    event Action InteractPressed;
    event Action PausePressed;

    void EnableGameplay();
    void EnableUI();
}